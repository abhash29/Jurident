import Product from './Product'
import React from 'react'

export default function ProductList(props) {
    
  return (
    props.product.map((product, i)=>{
        return <Product product={product} key={i}/>
    })
  )
}
