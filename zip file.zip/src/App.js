import './App.css';

import React, { useEffect, useState } from "react";

import axios from 'axios';

function App() {
  const [news, setNews] = useState([]);

  useEffect(() => {
    axios.get("https://newsapi.org/v2/top-headlines?country=us&category=business&apiKey=40090044ebbb4126ba8ee5c90d5ca9da")
      .then((res) => {
        console.log(res.data.articles);
        setNews(res.data.articles);
      })
  }, []);

  return (
    <>
      <div className="container my-5">
        <div className="row text-center">
          <div className="col">
            {
              news.map((val, index) => {
                return (
                  <div className="card" style={{ width: "18rem" }} key={index}>
                    {val.urlToImage ? (
                      <img src={val.urlToImage} className="card-img-top" alt="..." />
                    ) : (
                      <div className="card-img-top placeholder-image"></div>
                    )}
                    <div className="card-body">
                      <h5 className="card-title">{val.title}</h5>
                      <p className="card-text">
                        {val.description}
                      </p>
                    </div>
                  </div>
                )
              })
            }
          </div>
        </div>
      </div>
    </>
  );
}

export default App;
